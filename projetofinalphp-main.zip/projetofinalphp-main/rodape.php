<footer class="card">
    <div class="card-footer">Site Institucional</div>
    2025 &copy; Direitos Reservados
</footer>

</body>
</html>
