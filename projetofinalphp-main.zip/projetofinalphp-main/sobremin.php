<?php

    echo "<h3>Quem Sou</h3>";
?>

<p> 💈 Barbearia Paulo — João Pessoa (PB) <br>
    📍 Rua das Palmeiras, 428 – Bairro Cidade Verde, João Pessoa – PB</p>

<p> A Barbearia Paulo é aquele tipo de lugar onde você senta na cadeira e já se sente em casa. Localizada na charmosa Rua das Palmeiras, no bairro Cidade Verde, em João Pessoa, a barbearia combina tradição, cuidado e um atendimento totalmente personalizado. <br>

 Paulo, barbeiro com anos de experiência, trabalha sozinho e coloca atenção em cada detalhe — do corte clássico ao degradê mais moderno. Nada de pressa: aqui o foco é fazer um serviço bem feito, do jeitinho que você gosta. <br>

 O ambiente é simples, organizado e aconchegante, perfeito pra relaxar, trocar uma ideia e sair com o visual alinhado. Se você quer um atendimento próximo, profissional e feito com capricho, a Barbearia Paulo é o lugar certo.</p>
