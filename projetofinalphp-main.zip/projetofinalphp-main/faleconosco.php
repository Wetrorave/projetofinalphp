<h3>📞 Contato</h3>
<p>
<h5>📍 Endereço:</h5>
Rua das Palmeiras, 428 – Bairro Cidade Verde <br>
João Pessoa – PB

</p>
<p>
<h5>📱 WhatsApp:</h5>
(83) 9 9876-4321
</p>
<p>
<h5>⏰ Horário de Funcionamento:</h5>
Segunda a Sexta: 9h às 18h <br>
Sábado: 8h às 14h <br>
Domingos e feriados: fechado
</p>
<p>
<h5>📧 E-mail:</h5>
contato@barbeariapaulo.com
 </p>
<p>
<h5>📍 Como chegar:</h5>
Ficamos perto da praça principal do bairro Cidade Verde, bem fácil de localizar.</p>