<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">

        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active" href="?pg=conteudo">Início</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=servicoseprecos">Serviços & Preços</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=minhagaleria">Galeria</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=agenda/agendamento">Agendamento</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=faleconosco">Contato</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=sobremin">Sobre Mim</a>
            </li>
        </ul>

        <!-- LOGO REDONDA NA NAV BAR -->
        <a class="navbar-brand ms-auto" href="?pg=conteudo">
            <img src="Admin/galeria/imagens/img-logo.png"
                 alt="Logo"
                 style="height:55px; width:55px; object-fit:cover; border-radius:50%;">
        </a>

    </div>
</nav>
