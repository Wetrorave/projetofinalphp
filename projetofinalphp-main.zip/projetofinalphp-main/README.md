# projetofinalphp

O projeto consiste em desenvolver um marketplace básico de usados, onde diferentes usuários podem se cadastrar, anunciar produtos e interagir com compradores por meio de um sistema simples de listagem e carrinho. É uma versão reduzida dos grandes marketplaces existentes (como OLX), com foco no aprendizado de PHP, banco de dados relacional e uso de sessões.

## Integrantes da equipe:

* Willian Gabriel Félix Farias
* Nicolas Nery da Silva Feitosa
* Isacsson Joabe Lima Cruz
* Gabriel Sales Mendes
