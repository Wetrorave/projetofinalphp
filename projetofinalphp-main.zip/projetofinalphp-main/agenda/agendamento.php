<h1>Cadastro do agendamento</h1>
<form action="?pg=agenda/agen-cadastro" method="post">
    <label>Nome</label>
    <input type="text" name="nome" placeholder="Seu nome"><br>
    <label>telefone</label>
    <input type="text" name="telefone" placeholder="Telefone"><br>
    <label>data</label>
    <input type="date" name="data1" ><br>
    <label>hora</label>
    <input type="time" name="hora">

    <input type="submit" value="Agendar">

</form>