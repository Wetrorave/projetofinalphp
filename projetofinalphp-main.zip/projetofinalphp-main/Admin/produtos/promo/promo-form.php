<h1>Cadastro de Promoções</h1>
<form action="?pg=produtos/promo/promo-cadastro" method="post">
    <label>Nome da promoção</label>
    <input type="text" name="nome" ><br>
    <label>Preço normal</label>
    <input type="text" name="preco" ><br>
    <label>Preço na promoção</label>
    <input type="text" name="precocompromo" ><br>

    <input type="submit" value="Cadastrar">
</form>