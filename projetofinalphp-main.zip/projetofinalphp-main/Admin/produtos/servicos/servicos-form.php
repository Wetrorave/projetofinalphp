<h1>Cadastro de cortes</h1>
<form action="?pg=produtos/servicos/servicos-cadastro" method="post">
    <label>Nome do corte</label>
    <input type="text" name="nome" ><br>
    <label>Discrição</label>
    <input type="text" name="descricao" ><br>
    <label>Preco</label>
    <input type="text" name="preco" ><br>

    <input type="submit" value="Cadastrar corte">
</form>